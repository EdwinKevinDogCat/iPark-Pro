/*
Parking Permit/License Plate Detector
Authors: Edwin Chen, Minseong Baek, Connor Morrissey, Ideen Nasseri-Moghaddam, Justin Liang
Date: January 11, 2024
Class: ICS4UI
Description of Code: this code allows for users to enter a parking permit ID and license plate. The entered values are checked to see if they are stored in a csv file for WCI members, "parking_permit.csv". If one of the entered values is not found in the csv file, a message will pop up, notifying that the user is not a WCI member, and that they should be fined $30. The code also checks whether a parking permit's expiry date is reached. If the expiry date is reached, a message will pop up, notifying that the parking permit is expired, and that the driver should be fined.
*/

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.text.*;

public class CarDetector extends JFrame {
    private JTextField IDField, LicenseField;

    public CarDetector() {
        super("Valid Car Detector");

        // label describing the purpose of the code
        JLabel InstrucLabel = new JLabel("This is a tool used for detecting whether a driver has a valid parking permit or not. ");
        InstrucLabel.setBounds(0, 80, 800, 50);
        InstrucLabel.setHorizontalAlignment(JTextField.CENTER);
        InstrucLabel.setFont(new Font("Dialog", Font.BOLD, 15));
        InstrucLabel.setForeground(new Color(2, 122, 34));

        // label for instructions: enter parking permit ID / car license plate
        JLabel IDLabel = new JLabel("Please enter the parking permit ID: ");
        IDField = new JTextField(20);
        IDLabel.setBounds(180, 220, 300, 30);
        IDField.setBounds(460, 220, 150, 30);
        JLabel LicenseLabel = new JLabel("Please enter the car's license plate: ");
        LicenseField = new JTextField(20);
        LicenseLabel.setBounds(180, 380, 300, 30);
        LicenseField.setBounds(460, 380, 150, 30);

        // button to check if the entered parking permit ID and license plate are valid
        JButton checkButton = new JButton("Check");
        checkButton.setForeground(Color.WHITE);
        checkButton.setBackground(new Color(42, 198, 250));
        checkButton.setBounds(600, 460, 80,30);
        checkButton.setHorizontalAlignment(JTextField.CENTER);
        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ValidCar();
            }
        });

        // button to return to main menu of the app
        JButton mainMenuButton = new JButton("Main Menu");
        mainMenuButton.setBackground(Color.RED);
        mainMenuButton.setBounds(100, 460, 120, 30);
        mainMenuButton.setHorizontalAlignment(JTextField.CENTER);
        mainMenuButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });


        add(InstrucLabel);
        add(IDLabel);
        add(IDField);
        add(LicenseLabel);
        add(LicenseField);
        add(checkButton);
        add(mainMenuButton);

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setVisible(true);
    }

    // void for checking if the entered parking permit ID and license plate are valid
    private void ValidCar() {
        String csvSplitBy = ",";

        String IDString = IDField.getText().strip();
        String LicenseString = LicenseField.getText().strip();
        try {
            BufferedReader br = new BufferedReader(new FileReader("parking_permit.csv"));
            
            String header = br.readLine(); // first line of csv file, store column titles
            String nextline;
          
            // ArrayList of all driver data, where the driver has the parking ID listed
            ArrayList<String[]> allMatch = new ArrayList<>();

            // if parking permit ID not inputted, let the user know
            if (IDString.equals("")) {
                JOptionPane.showMessageDialog(this, "Please enter the driver's parking permit ID. ");
            }
            else {
                // iterate through each line in the csv file to see if the ID occurs in the csv file
                while ((nextline = br.readLine()) != null) {
                    String[] nextRow = nextline.split(csvSplitBy);

                    // if the ID is detected in the parking permit csv file,
                    // add the row to allMatch ArrayList
                    if (nextRow[7].equals(IDString)) {
                        allMatch.add(nextRow);
                    }
                }
                // if nobody has the parking ID, let the user know to fine $30
                if (allMatch.size() == 0) {
                    JOptionPane.showMessageDialog(this, "Invalid parking permit ID. Fine $30. ");
                }
                else {
                    // if the parking permit ID is detected, next step is to check the license plate
                    // if license plate is not entered, let user know
                    if (LicenseString.equals("")) {
                        JOptionPane.showMessageDialog(this, "Please enter the car's license plate. ");
                    }
                    // if license plate does not match with the parking permit ID, let user know that the driver is not allowed to park in the parking space
                    else {
                        if (!inArray(allMatch, LicenseField.getText())) {
                            JOptionPane.showMessageDialog(this, "Invalid license plate. Fine $30. ");
                        }
                        else {
                            String permitExpiry = allMatch.get(0)[8];
                            String currentDate = CurrentDate();

                            // Note: for the future, we will try to figure out how to send an email to someone using Java
                            // test to see whether a parking permit has expired or not by comparing current date and the expiry date on the license plate
                            if (Compare2Dates(permitExpiry, currentDate) == false) {
                                JOptionPane.showMessageDialog(this, "The parking permit needs to be renewed. The expiry date was " + permitExpiry + ". Fine $30. ");
                            }
                            else {
                                JOptionPane.showMessageDialog(this, "Valid parking permit and car, and the expiry date has not been reached. All good!");
                            }
                        }
                    }
                }
            }
        }
        // IOException
        catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while writing to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        // ParseException
        catch (ParseException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred when determining whether your arking permit has expired or not. ", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // function to check whether a license plate is in an ArrayList of driver registration info with a given parking permit ID
  
    public static boolean inArray(ArrayList<String[]> AL, String s) {
        boolean contain = false;
        for (String[] SL : AL) {
            // check if the 5th element in the row is equal to the license plate
            // the 5th column is for the license plates
            if (SL[4].equals(s)) {
                contain = true;
                break;
            }
        }
        return contain;
    }

    // function to get the current date
    public static String CurrentDate() {
        // Get the current year, month, and day
        int currYear = Calendar.getInstance().get(Calendar.YEAR);
        int currMonth = Calendar.getInstance().get(Calendar.MONTH);
        int currDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        Calendar currDate = Calendar.getInstance();
        currDate.set(Calendar.YEAR, currYear);
        currDate.set(Calendar.MONTH, currMonth);
        currDate.set(Calendar.DAY_OF_MONTH, currDay);

        // Format expiry date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedCurrDate = dateFormat.format(currDate.getTime());

        return formattedCurrDate;
    }

    // function for comparing two dates
    // (check if present date is past driver's parking permit expiry date)
    public static boolean Compare2Dates(String date1, String date2) throws ParseException {
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
        Date d1 = sdformat.parse(date1);
        Date d2 = sdformat.parse(date2);
        if (d1.compareTo(d2) >= 0) {
            return true;
        }
        else {
            return false;
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CarDetector());
    }
}
