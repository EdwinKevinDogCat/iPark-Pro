/*
Parking Permit/License Plate Detector
Authors: Edwin Chen, Minseong Baek, Connor Morrissey, Ideen Nasseri-Moghaddam, Justin Liang
Date: January 11, 2024
Class: ICS4UI
Description of Code: this code allows people to register for a school parking lot by providing their personal information and car information
*/

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class PPR extends JFrame {

    private JTextField nameField, emailField, phoneField, carModelField1, carLicenseField1, colorField1, yearField1, 
    carModelField2, carLicenseField2, colorField2, yearField2;

    public PPR() {
        super("Parking Permit Registration");
        // display an overview of what the code does
        JLabel infoLabel1 = new JLabel("Here, you can register for a school parking permit");
        infoLabel1.setBounds(0, 25, 800, 30);
        infoLabel1.setFont(new Font("Dialog", Font.BOLD, 18));
        infoLabel1.setForeground(new Color(2, 122, 34));
        infoLabel1.setHorizontalAlignment(JTextField.CENTER);

        JLabel infoLabel2 = new JLabel("by providing your contact information and information about your car(s).");
        infoLabel2.setBounds(0, 65, 800, 30);
        infoLabel2.setFont(new Font("Dialog", Font.BOLD, 18));
        infoLabel2.setForeground(new Color(2, 122, 34));
        infoLabel2.setHorizontalAlignment(JTextField.CENTER);

        // labels and text fiels to collect user's name, email, and phone number
        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel phoneLabel = new JLabel("Phone:");
        nameField = new JTextField(20);
        emailField = new JTextField(20);
        phoneField = new JTextField(20);
        nameLabel.setBounds(330, 120, 50, 30);
        emailLabel.setBounds(330, 170, 50, 30);
        phoneLabel.setBounds(330, 220, 50, 30);
        nameField.setBounds(400, 120, 150, 30);
        emailField.setBounds(400, 170, 150, 30);
        phoneField.setBounds(400, 220, 150, 30);

        // letting user know to enter car information for 1-2 cars
        JLabel carLabel = new JLabel("Please enter the data for your car(s). Each parking permit can be used for at most two cars.");
        carLabel.setFont(new Font("Serif", Font.PLAIN, 15));
        carLabel.setBounds(0, 280, 800, 20);
        carLabel.setHorizontalAlignment(JTextField.CENTER);

        // info for first car
        JLabel Label1 = new JLabel("Car 1 (*required)");
        Label1.setBounds(40, 310, 150, 30);
        Label1.setForeground(Color.RED);

        JLabel carModelLabel1 = new JLabel("Car Model:");
        JLabel carLicenseLabel1 = new JLabel("License Plate:");
        JLabel colorLabel1 = new JLabel("Car Color:");
        JLabel yearLabel1 = new JLabel("Date of Manufacture:");
        carModelField1 = new JTextField(20);
        carLicenseField1 = new JTextField(20);
        colorField1 = new JTextField(20);
        yearField1 = new JTextField(20);
        carModelLabel1.setBounds(40, 350, 100, 30);
        carLicenseLabel1.setBounds(40, 390, 100, 30);
        colorLabel1.setBounds(40, 430, 100, 30);
        yearLabel1.setBounds(40, 470, 200, 30);
        carModelField1.setBounds(200, 350, 150, 30);
        carLicenseField1.setBounds(200, 390, 150, 30);
        colorField1.setBounds(200, 430, 150, 30);
        yearField1.setBounds(200, 470, 150, 30);

        // info for second car
        JLabel Label2 = new JLabel("Car 2 (optional)");
        Label2.setBounds(440, 310, 150, 30);

        JLabel carModelLabel2 = new JLabel("Car Model:");
        JLabel carLicenseLabel2 = new JLabel("License Plate:");
        JLabel colorLabel2 = new JLabel("Car Color:");
        JLabel yearLabel2 = new JLabel("Date of Manufacture:");
        carModelField2 = new JTextField(20);
        carLicenseField2 = new JTextField(20);
        colorField2 = new JTextField(20);
        yearField2 = new JTextField(20);
        carModelLabel2.setBounds(440, 350, 100, 30);
        carLicenseLabel2.setBounds(440, 390, 100, 30);
        colorLabel2.setBounds(440, 430, 100, 30);
        yearLabel2.setBounds(440, 470, 200, 30);
        carModelField2.setBounds(600, 350, 150, 30);
        carLicenseField2.setBounds(600, 390, 150, 30);
        colorField2.setBounds(600, 430, 150, 30);
        yearField2.setBounds(600, 470, 150, 30);

        // register button, stores user's information in a csv file "parking_permit.csv"
        JButton registerButton = new JButton("Register");
        registerButton.setBackground(new Color(42, 198, 250));
        registerButton.setBounds(600, 520, 120, 30);
        registerButton.setHorizontalAlignment(JTextField.CENTER);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerParkingPermit();
            }
        });

        // main menu button, returns user back to main menu of app
        JButton mainMenuButton = new JButton("Main Menu");
        mainMenuButton.setBackground(Color.RED);
        mainMenuButton.setBounds(200, 520, 120, 30);
        mainMenuButton.setHorizontalAlignment(JTextField.CENTER);
        mainMenuButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        // add all labels and text boxes on the screen
        add(infoLabel1);
        add(infoLabel2);
        add(nameLabel);
        add(emailLabel);
        add(phoneLabel);
        add(nameField);
        add(emailField);
        add(phoneField);
        add(carLabel);
        add(Label1);
        add(carModelLabel1);
        add(carLicenseLabel1);
        add(colorLabel1);
        add(yearLabel1);
        add(carModelField1);
        add(carLicenseField1);
        add(colorField1);
        add(yearField1);
        add(Label2);
        add(carModelLabel2);
        add(carLicenseLabel2);
        add(colorLabel2);
        add(yearLabel2);
        add(carModelField2);
        add(carLicenseField2);
        add(colorField2);
        add(yearField2);
        add(registerButton);
        add(mainMenuButton);
        
        setSize(800, 600);
        setBackground(new Color(252, 207, 159));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setVisible(true);
    }

    // java void function for registering for a parking permit
    private void registerParkingPermit() {
        // read all text that user has inputted
        String name = nameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();

        String carModel1 = carModelField1.getText();
        String carLicense1 = carLicenseField1.getText();
        String color1 = colorField1.getText();
        String year1 = yearField1.getText();

        String carModel2 = carModelField2.getText();
        String carLicense2 = carLicenseField2.getText();
        String color2 = colorField2.getText();
        String year2 = yearField2.getText();


        try (BufferedWriter writer = new BufferedWriter(new FileWriter("parking_permit.csv", true))) {
            // if any personal info text boxes are blank, give user a message to let them know
            if (name.equals("") || email.equals("") || phone.equals("")) {
                JOptionPane.showMessageDialog(this, "Please make sure the name, email, and phone input fields are filled in.");
            }
            
            else {
                // write car info in the "parking_permit.csv" file
                if (!carModel1.equals("") && !carLicense1.equals("") && !color1.equals("") && !year1.equals("")) {
                  
                    String parkingID = generateRandomID();
                    String expiryDate = ExpiryDate();
                    writer.write(name + "," + email + "," + phone + "," + carModel1 + "," + carLicense1 + "," + color1 + "," + year1 + "," + parkingID + "," + expiryDate);
                    writer.newLine();
                    writer.flush();
                    JOptionPane.showMessageDialog(this, "Registration successful for Car 1!");
                    if (!carModel2.equals("") && !carLicense2.equals("") && !color2.equals("") && !year2.equals("")) {
                        writer.write(name + "," + email + "," + phone + "," + carModel2 + "," + carLicense2 + "," + color2 + "," + year2 + "," + parkingID + "," + expiryDate);
                        writer.newLine();
                        writer.flush();
                        JOptionPane.showMessageDialog(this, "Registration successful for Car 2!");
                    }
                    // Tell user their parking permit ID and the date of expiry (June 30 of the current year, all school parking permits are only for use during school time)
                    JOptionPane.showMessageDialog(this, "Your parking permit ID is: " + parkingID + "\nand the date of expiry is " + expiryDate + ".");
                    // make all text fields empty using clearFields() function
                    clearFields();
                }
                  // if any car info text boxes are blank, give user a message to let them know
                else {
                    JOptionPane.showMessageDialog(this, "Please fill out all information for at least one car. ");
                }
            }
        }
        // IOException
        catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while writing to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // function for generating a random 10-digit parking permit ID for someone who has just registered
    public String generateRandomID() {
        StringBuilder ID = new StringBuilder();
        Random rand = new Random();
        for (int i = 0; i < 10; i++) {
            int n = rand.nextInt(10);
            ID.append(n);
        }
        return ID.toString();
    } 

    // function for clearing all text fields (done after registration is successful)
    private void clearFields() {
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        carModelField1.setText("");
        carLicenseField1.setText("");
        colorField1.setText("");
        yearField1.setText("");
        carModelField2.setText("");
        carLicenseField2.setText("");
        colorField2.setText("");
        yearField2.setText("");
    }

    // function to get the expiry date of the parking permit (end of June in the current year)
    private String ExpiryDate() {
        // Get the current year
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        // Set the expiry date to the end of June for the current year
        Calendar expiryDate = Calendar.getInstance();
        expiryDate.set(Calendar.YEAR, currentYear);
        expiryDate.set(Calendar.MONTH, Calendar.JUNE);
        expiryDate.set(Calendar.DAY_OF_MONTH, expiryDate.getActualMaximum(Calendar.DAY_OF_MONTH));

        // Format expiry date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedExpiryDate = dateFormat.format(expiryDate.getTime());

        return formattedExpiryDate;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PPR());
    }
}
